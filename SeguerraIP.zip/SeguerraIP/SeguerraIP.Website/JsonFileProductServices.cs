﻿namespace SeguerraIP.Website
{
    internal class JsonFileProductServices
    {
    }
}