﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;
using SeguerraIP.Website.Models;
using SeguerraIP.Website.Services;

namespace SeguerraIP.Website.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        public JsonFileProductService ProductServices;
        public IEnumerable<Product> Products { get; private set; }
        public object ProductsService { get; private set; }

        public IndexModel(ILogger<IndexModel> logger,
             JsonFileProductService productService)
        {
            _logger = logger;
            ProductsService = productService;
        }

        public void OnGet()
        {
            Products = ProductsService.GetProducts();
        }
    }
}